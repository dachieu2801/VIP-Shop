<?php
/**
 * country.php
 *
 * @copyright  2022 beikeshop.com - All Rights Reserved
 * @link       https://beikeshop.com
 * @author     TL <mengwb@guangda.work>
 * @created    2022-08-29 17:21:38
 * @modified   2022-08-29 17:21:38
 */
return [
    'country_name'     => '国家/地区',

    'countries_index'  => '国家/地区列表',
    'countries_create' => '创建国家/地区',
    'countries_update' => '更新国家/地区',
    'countries_delete' => '删除国家/地区',
];
