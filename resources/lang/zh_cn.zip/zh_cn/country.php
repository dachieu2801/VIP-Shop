<?php
/**
 * currency.php
 *
 * @copyright  2022 beikeshop.com - All Rights Reserved
 * @link       https://beikeshop.com
 * @author     TL <mengwb@guangda.work>
 * @created    2022-07-28 17:21:38
 * @modified   2022-07-28 17:21:38
 */
return [
    'AF'       => '非洲',
    'AN'       => '南极洲',
    'AS'       => '亚洲',
    'EU'       => '欧洲',
    'NA'       => '北美洲',
    'OA'       => '大洋洲',
    'SA'       => '南美洲',
    'null'     => '未知',
];
